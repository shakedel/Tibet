﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace humanSeminarTextCompare
{

    //Coding By Sara El-Sayed El-Metwally @ Monday,19-12-2011, 9:00 pm
    // Teaching Assistant ,Mansoura University ,Eygpt 
    class DynamicProgramming
    {

        public static Cell[,] Intialization_Step(string Seq1, string Seq2,int Sim,int NonSimilar,int Gap)
        {
            int M = Seq1.Length;//Length+1//-AAA
            int N = Seq2.Length;//Length+1//-AAA

            Cell[,] Matrix = new Cell[N, M];
            //Intialize the first Row With Gap Penality Equal To i*Gap 
            for (int i = 0; i < Matrix.GetLength(1); i++)
            {
                if (i == 0)
                {

                    Matrix[0, i] = new Cell(0, i, i * Gap);
                }
                else
                {
                    Matrix[0, i] = new Cell(0, i, i * Gap, Matrix[0, i - 1], Cell.PrevcellType.Left);
                }
            }

            //Intialize the first Column With Gap Penality Equal To i*Gap 
            for (int i = 0; i < Matrix.GetLength(0); i++)
            {
                if (i == 0)
                {
                    Matrix[i, 0] = new Cell(i, 0, i * Gap);
                }
                else
                {
                    Matrix[i, 0] = new Cell(i, 0, i * Gap, Matrix[i-1,0], Cell.PrevcellType.Above);
                }
            }
            // Fill Matrix with each cell has a value result from method Get_Max
            for (int j = 1; j < Matrix.GetLength(0); j++)
            {
                for (int i = 1; i < Matrix.GetLength(1); i++)
                {
                    Matrix[j, i] = Get_Max(i, j, Seq1, Seq2, Matrix,Sim,NonSimilar,Gap);


                }

            }

            return Matrix;


        }

        public static Cell Get_Max(int i, int j, string Seq1, string Seq2, Cell[,] Matrix,int Similar,int NonSimilar,int GapPenality)
        {
            Cell Temp = new Cell();
            int Sim;
            int Gap = GapPenality;
            if (Seq1[i] == Seq2[j])
                Sim = Similar;
            else
                Sim = NonSimilar;
            int M1, M2, M3;
            M1 = Matrix[j - 1, i - 1].CellScore + Sim;
            M2 = Matrix[j, i - 1].CellScore + Gap;
            M3 = Matrix[j - 1, i].CellScore + Gap;

            int max = M1 >= M2 ? M1 : M2;
            int Mmax = M3 >= max ? M3 : max;
            if (Mmax == M1)
            { Temp = new Cell(j, i, M1, Matrix[j - 1, i - 1], Cell.PrevcellType.Diagonal); }
            else
            {
                if (Mmax == M2)
                { Temp = new Cell(j, i, M2, Matrix[j, i - 1], Cell.PrevcellType.Left); }
                else
                {
                    if (Mmax == M3)
                    { Temp = new Cell(j, i, M3, Matrix[j - 1, i], Cell.PrevcellType.Above); }
                }
            }

            return Temp;
        }

        public static void Traceback_Step(Cell[,] Matrix, string Sq1, string Sq2, List<char> Seq1, List<char> Seq2)
        {

            //List<char> Seq1 = new List<char>();
            //List<char> Seq2 = new List<char>();
            Cell CurrentCell = Matrix[Sq2.Length - 1, Sq1.Length - 1];


            while (CurrentCell != null)
            {
                if (CurrentCell.Type == Cell.PrevcellType.Diagonal)
                {

                    Seq1.Add(Sq1[CurrentCell.CellColumn]);
                    Seq2.Add(Sq2[CurrentCell.CellRow]);

                }
                if (CurrentCell.Type == Cell.PrevcellType.Left)
                {
                    Seq1.Add(Sq1[CurrentCell.CellColumn]);
                    Seq2.Add('-');

                }
                if (CurrentCell.Type == Cell.PrevcellType.Above)
                {
                    Seq1.Add('-');
                    Seq2.Add(Sq2[CurrentCell.CellRow]);

                }

                CurrentCell = CurrentCell.CellPointer;

            }


           

        }
    }
}
