﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace humanSeminarTextCompare
{
    class MyGlobalAligner
    {
        public static Tuple<String, String> globalAlignment(String str1, String str2)
        {
            int matchScore = 1;
            int mismatchScore = -1;
            int gapScore = -1;

            int m = str1.Length;
            int n=str2.Length;
            Cell[,] Matrix = new Cell[m+1, n+1];

            for (int i = 1; i <= m; i++)
            {
                Matrix[i, 0] = new Cell(i, 0, gapScore * i, Matrix[i - 1, 0], Cell.PrevcellType.Above);
            }

            for (int i = 1; i <= n; i++)
            {
                Matrix[0, i] = new Cell(0, i, gapScore * i, Matrix[0, i - 1], Cell.PrevcellType.Left);
            }

            Matrix[0, 0] = new Cell(0, 0, 0, null);

            for (int i = 1; i <= m; i++)
            {
                for (int j = 1; j <= n; j++)
                {
                    char relevantStr1Char = str1[i - 1];
                    char relevantStr2Char = str2[j - 1];

                    int bestScore = int.MinValue;

                    int gapUpScore = Matrix[i - 1, j].CellScore + gapScore;
                    int gapLeftScore = Matrix[i, j-1].CellScore + gapScore;
                    int diagScore = Matrix[i - 1, j - 1].CellScore;

                    if (relevantStr1Char == relevantStr2Char)
                    {
                        diagScore += matchScore;
                    }
                    else
                    {
                        diagScore += mismatchScore;
                    }

                    if (gapUpScore > bestScore)
                    {
                        bestScore = gapUpScore;
                        Matrix[i, j] = new Cell(i, j, gapUpScore, Matrix[i - 1, j], Cell.PrevcellType.Above);
                    }

                    if (gapLeftScore > bestScore)
                    {
                        bestScore = gapLeftScore;
                        Matrix[i, j] = new Cell(i, j, gapLeftScore, Matrix[i, j-1], Cell.PrevcellType.Left);
                    }

                    if (diagScore > bestScore)
                    {
                        bestScore = diagScore;
                        Matrix[i, j] = new Cell(i, j, diagScore, Matrix[i - 1, j-1], Cell.PrevcellType.Diagonal);
                    }
                }
            }

            String align1 = "";
            String align2 = "";

            Cell currentCell = Matrix[m, n];
            int currentStr1Idx = m-1;
            int currentStr2Idx = n-1;
            char gapChar = '-';
            while (currentCell.CellPointer != null)
            {
                switch (currentCell.Type)
                {
                    case Cell.PrevcellType.Diagonal:
                        align1 = str1[currentStr1Idx] + align1;
                        align2 = str2[currentStr2Idx] + align2;
                        currentStr1Idx--;
                        currentStr2Idx--;
                        break;
                    case Cell.PrevcellType.Above:
                        align1 = str1[currentStr1Idx] + align1;
                        align2 = gapChar + align2;
                        currentStr1Idx--;
                        break;
                    case Cell.PrevcellType.Left:
                        align1 = gapChar + align1;
                        align2 = str2[currentStr2Idx] + align2;
                        currentStr2Idx--;
                        break;
                }

                currentCell = currentCell.CellPointer;
            }

            return new Tuple<String, String>(align1, align2);
        }
    }
}
